<script setup>
import { RouterLink, RouterView } from 'vue-router'
import Navbar from './components/Navbar.vue'
import Container from './components/Container.vue'
</script>

<template>
<Navbar />
<Container />
    <div>
      <nav>
      <RouterLink to="/" style="color: white;">Info e recensioni</RouterLink>
        <RouterLink to="/about" style="color: white;">About</RouterLink>
      </nav>
    </div>

  <RouterView />
</template>

<style scoped>

</style>
