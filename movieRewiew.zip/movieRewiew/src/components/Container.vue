<script>
import axios from 'axios';
export default{ 
  data() {
    return {
      films: [],
      selectedId: 0
    }
  },
  mounted(){
        axios
        .get('https://api.themoviedb.org/3//trending/movie/week?page=1&api_key=6f9286d54de4891ea7a5c91779e09786&language=it')
        .then(response => this.films = response.data.results)
    },
  methods: {
    ReturnImage(film){
      return "https://image.tmdb.org/t/p/w500" + film.backdrop_path
    }
  }
}
</script>
<template>
    <div class="container tabella">
    <div class="row" v-for="film in films" :key="film.id">
      <div class="col-4">
      
      </div>
      <div class="col-4">
        <div>
        <div class="card" style="width: 27rem; height: 20rem;">
          <img :src="ReturnImage(film)" class="card-img-top">
          <h5 class="card-title ">{{ film.title }}</h5>
          <a href="/" class="btn btn-warning" style="height: 190px;width:425px; font-weight: bold;font-size: large;" :film="film">Info e recensioni</a>
        </div>
        </div>
        <br>
      </div>
      <div class="col-4">
      </div>
    </div>
  </div>
  </template>


<style>
.tabella{
  background-color: black;
  text-align: center;
}
.films {
  text-align: center;
  padding-left: 70px;
}
.card {
  border: 5px solid gold;
  background-color: gold;
  color: black;
}
.card-title {
  font-weight: bold;

}
.navbar {
  background-color: gold;
  color: black;
  font-family: 'Courier New', Courier, monospace;
  font-size: large;
  font-weight: bold;
}
.popularity {
  text-align: center;
  color: gold;
  font-size: large;
  font-family: 'Courier New', Courier, monospace;
  font-weight: bold;
}
</style>
<!--this.films = response.data.results
<div v-for="post in posts" :key="post.id">
    <h2>{{ post.id }} {{ post.title }}</h2>
    <p>{{ post.body }}</p>
  </div>
  .get('https://jsonplaceholder.typicode.com/posts') da inserire nella funzione mounted()
  data() {
    return {
      posts: []
    }
  },-->
  <!--<section>
    <form @submit.prevent="createPost">
      <div>
        <label for="userId">UserID:</label>
        <input type="text" id="userId" v-model="postData.userId">
      </div>
      <div>
        <label for="title">Title:</label>
        <input type="text" id="title" v-model="postData.title">
      </div>
      <div>
        <label for="body">Body:</label>
        <textarea id="body" rows="6" cols="22" v-model="postData.body"></textarea>
      </div>
      <button>Create Post</button>
    </form>
  </section>
  .post('https://jsonplaceholder.typicode.com/posts', this.postData)
  data() {
    return {
      postData: { userid: '', title: '', body: '' }
    }
  },
   
  methods: {

    createPost(){
        axios
        .post('https://jsonplaceholder.typicode.com/posts', this.postData) 
        .then(response =>console.log(response))
    }
  }
  -->
  <!-- METODO PUT
  mounted(){
        axios
        .put('https://jsonplaceholder.typicode.com/posts/1',{
          id:'1',
          userId: '1',
          title: 'Article Title',
          body: 'Article body'
        }) 
        .then(response =>console.log(response))
  }-->
  <!-- METODO PATCH
    mounted(){
        axios
        .patch('https://jsonplaceholder.typicode.com/posts/1',{
          title: 'Article Title',
        }) 
        .then(response =>console.log(response))
  }-->

  <!-- METODO DELETE
  mounted(){
        axios
        .delete('https://jsonplaceholder.typicode.com/posts/1') 
        .then(response =>console.log(response))
  }-->

  <!-- METODO ERROR
  mounted(){
        axios
        .get('https://jsonplaceholder.typicode.com/wrong') 
        .catch(error => console.log(error))
  }-->




