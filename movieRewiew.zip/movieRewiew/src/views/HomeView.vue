<script>
import axios from 'axios';
export default{ 
  props: {
    filmSelected: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      
    }
  },
  mounted(){
    
    },
  methods: {
    ReturnImage(){
      return "https://image.tmdb.org/t/p/w500" + filmSelected.backdrop_path
    }
  }
}
</script>
<template>
    <div class="grid tabella">
  <div class="g-col-6 card">prova 1</div>
  <div class="g-col-6 card">prova 2</div>

  <div class="g-col-6 card">.g-col-6</div>
  <div class="g-col-6 card">.g-col-6</div>
</div>
</template>
<style>
.tabella{
  background-color: black;
  text-align: center;
}
.films {
  text-align: center;
  padding-left: 70px;
}
.card {
  border: 5px solid gold;
  background-color: gold;
  color: black;
}
.card-title {
  font-weight: bold;

}
.navbar {
  background-color: gold;
  color: black;
  font-family: 'Courier New', Courier, monospace;
  font-size: large;
  font-weight: bold;
}
.popularity {
  text-align: center;
  color: gold;
  font-size: large;
  font-family: 'Courier New', Courier, monospace;
  font-weight: bold;
}
</style>
<!--this.films = response.data.results
<div v-for="post in posts" :key="post.id">
    <h2>{{ post.id }} {{ post.title }}</h2>
    <p>{{ post.body }}</p>
  </div>
  .get('https://jsonplaceholder.typicode.com/posts') da inserire nella funzione mounted()
  data() {
    return {
      posts: []
    }
  },-->
  <!--<section>
    <form @submit.prevent="createPost">
      <div>
        <label for="userId">UserID:</label>
        <input type="text" id="userId" v-model="postData.userId">
      </div>
      <div>
        <label for="title">Title:</label>
        <input type="text" id="title" v-model="postData.title">
      </div>
      <div>
        <label for="body">Body:</label>
        <textarea id="body" rows="6" cols="22" v-model="postData.body"></textarea>
      </div>
      <button>Create Post</button>
    </form>
  </section>
  .post('https://jsonplaceholder.typicode.com/posts', this.postData)
  data() {
    return {
      postData: { userid: '', title: '', body: '' }
    }
  },
   
  methods: {

    createPost(){
        axios
        .post('https://jsonplaceholder.typicode.com/posts', this.postData) 
        .then(response =>console.log(response))
    }
  }
  -->
  <!-- METODO PUT
  mounted(){
        axios
        .put('https://jsonplaceholder.typicode.com/posts/1',{
          id:'1',
          userId: '1',
          title: 'Article Title',
          body: 'Article body'
        }) 
        .then(response =>console.log(response))
  }-->
  <!-- METODO PATCH
    mounted(){
        axios
        .patch('https://jsonplaceholder.typicode.com/posts/1',{
          title: 'Article Title',
        }) 
        .then(response =>console.log(response))
  }-->

  <!-- METODO DELETE
  mounted(){
        axios
        .delete('https://jsonplaceholder.typicode.com/posts/1') 
        .then(response =>console.log(response))
  }-->

  <!-- METODO ERROR
  mounted(){
        axios
        .get('https://jsonplaceholder.typicode.com/wrong') 
        .catch(error => console.log(error))
  }-->




